/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectuas;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class FXMLDocumentController implements Initializable {
    
   
   @FXML
    private TextField nama;

    @FXML
    private TextField ttl;

    @FXML
    private TextField jk;

    @FXML
    private TextField alamat;

    @FXML
    private TextField agama;
    
    @FXML
    private TextField status;
    
    @FXML
    private TextField divisi;

    @FXML
    private TextField jabatan;

    @FXML
    private TableView<karyawan> colom;

    @FXML
    private TableColumn<karyawan, String> cnama;

    @FXML
    private TableColumn<karyawan, String> cttl;

    @FXML
    private TableColumn<karyawan, String> cjk;

    @FXML
    private TableColumn<karyawan, String> calamat;

    @FXML
    private TableColumn<karyawan, String> cagama;

    @FXML
    private TableColumn<karyawan, String> cstatus;

    @FXML
    private TableColumn<karyawan, String> cjabatan;

    @FXML
    private TableColumn<karyawan, String> cdivisi;

    @FXML
    private Button simpan;
    
    @FXML
    private Button edit;

    @FXML
    private Button hapus;
    
    
     ObservableList<karyawan>listM;
    int index = -1;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    
    public void simpan() throws SQLException{
        conn = kelolakaryawan.kelola();
        String sql = "insert into karyawan (nama,ttl,kelamin,alamat,agama,status,jabatan,divisi) values (?,?,?,?,?,?,?,?)";
        try{
            pst = conn.prepareStatement(sql);
            
            pst.setString(1,nama.getText() );
            pst.setString(2,ttl.getText() );
            pst.setString(3,jk.getText() );
            pst.setString(4,alamat.getText() );
            pst.setString(5,agama.getText() );
            pst.setString(6,status.getText() );
            pst.setString(7,jabatan.getText() );
            pst.setString(8,divisi.getText() );
            
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Berhasil di Simpan");
            Karyawan();
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
                
                
        }
    }
    
    public void edit() throws SQLException {
        conn = kelolakaryawan.kelola();
        try{
        String value1 =nama.getText();
        String value2 =ttl.getText();
        String value3 =jk.getText();
        String value4 =alamat.getText();
        String value5 =agama.getText();
        String value6 =status.getText();
        String value7 =jabatan.getText();
        String value8 =divisi.getText();
        
        String sql = "update karyawan set nama= '"+value1+"',ttl= '"+value2+"',kelamin= '"+
                    value3+"',alamat= '"+value4+"',agama= '"+value5+"',status= '"+value6+"',jabatan= '"+value7+"',divisi= '"+value8+"'  where nama='"+value1+"' ";
        pst= conn.prepareStatement(sql);
        pst.execute();
        JOptionPane.showMessageDialog(null, "Berhasil di Edit");
        Karyawan();
         } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
                
         }        
        }
    public void hapus() throws SQLException{
        conn = kelolakaryawan.kelola();
        String sql = "delete from karyawan where nama=?";
        try{
            pst = conn.prepareStatement(sql);
            pst.setString(1,nama.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil di Hapus");
            Karyawan();
         } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
                
         }        
        }

    public void Karyawan() {
        cnama.setCellValueFactory(new PropertyValueFactory<karyawan, String>("nama"));
        cttl.setCellValueFactory(new PropertyValueFactory<karyawan, String>("ttl"));
        cjk.setCellValueFactory(new PropertyValueFactory<karyawan, String>("kelamin"));
        calamat.setCellValueFactory(new PropertyValueFactory<karyawan, String>("alamat"));
        cagama.setCellValueFactory(new PropertyValueFactory<karyawan, String>("agama"));
        cstatus.setCellValueFactory(new PropertyValueFactory<karyawan, String>("status"));
        cjabatan.setCellValueFactory(new PropertyValueFactory<karyawan, String>("jabatan"));
        cdivisi.setCellValueFactory(new PropertyValueFactory<karyawan, String>("divisi"));
        
        listM = kelolakaryawan.getkaryawan();
        colom.setItems(listM);
        
        
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       Karyawan();
    }    
    
}
