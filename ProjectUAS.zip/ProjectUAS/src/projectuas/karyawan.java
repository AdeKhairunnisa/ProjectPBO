/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectuas;

/**
 *
 * @author ASUS
 */
public class karyawan {
   String nama;
   String ttl;
   String kelamin;
   String alamat;
   String agama;
   String status;
   String jabatan;
   String divisi;

    public karyawan(String nama, String ttl, String kelamin, String alamat, String agama, String status, String jabatan, String divisi) {
        this.nama = nama;
        this.ttl = ttl;
        this.kelamin = kelamin;
        this.alamat = alamat;
        this.agama = agama;
        this.status = status;
        this.jabatan = jabatan;
        this.divisi = divisi;
    }

   
   
    public String getNama() {
        return nama;
    }

    public String getTtl() {
        return ttl;
    }

    public String getKelamin() {
        return kelamin;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getAgama() {
        return agama;
    }

    public String getStatus() {
        return status;
    }

    public String getJabatan() {
        return jabatan;
    }

    public String getDivisi() {
        return divisi;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setTtl(String ttl) {
        this.ttl = ttl;
    }

    public void setKelamin(String kelamin) {
        this.kelamin = kelamin;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public void setAgama(String agama) {
        this.agama = agama;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    public void setDivisi(String divisi) {
        this.divisi = divisi;
    }

    
}