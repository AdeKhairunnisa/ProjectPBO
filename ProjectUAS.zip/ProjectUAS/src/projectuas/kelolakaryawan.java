/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectuas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class kelolakaryawan {
     Connection get = null;
     
     public static Connection kelola(){
  
        try{
       
           Connection get;
            get = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/pendataan","root","");
           
            return get;
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
     }
        
        public static ObservableList<karyawan> getkaryawan() {
            Connection get = kelola();
            ObservableList<karyawan> list = FXCollections.observableArrayList();
       try{ 
           PreparedStatement ps = (PreparedStatement) get.prepareStatement("select * from karyawan");
           ResultSet rs = ps.executeQuery();
           
           while (rs.next()){
             list.add(new karyawan(rs.getString("nama"), rs.getString("ttl"), rs.getString("kelamin"), rs.getString("alamat"), rs.getString("agama"),rs.getString("status"),rs.getString("jabatan"),rs.getString("divisi")));         
          }
        } catch (Exception e) {
        }
        return list;
    }
    
}
        

                 
    

